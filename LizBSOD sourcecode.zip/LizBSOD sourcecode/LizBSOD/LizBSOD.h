typedef struct IUnknown IUnknown;
#pragma once

#pragma warning(disable : 4993)

#include <Windows.h>
#include <tlhelp32.h>

#include "Payloads.h"
